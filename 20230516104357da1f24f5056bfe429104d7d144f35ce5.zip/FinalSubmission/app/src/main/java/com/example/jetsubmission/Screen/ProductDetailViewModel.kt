package com.example.jetsubmission.Screen

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.jetsubmission.Model.ProductList

class ProductDetailViewModel: ViewModel() {
    private val selectProduct = MutableLiveData<ProductList>()

    fun selectProduct(product: ProductList){
        selectProduct.value = product
    }

    fun clearSelectProduct(){
        selectProduct.value = null
    }


}