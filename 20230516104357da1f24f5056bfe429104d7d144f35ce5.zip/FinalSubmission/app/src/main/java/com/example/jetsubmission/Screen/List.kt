import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.jetsubmission.Model.ProductList
import com.example.jetsubmission.Model.ProductListItem

@Composable
fun Product(productList:  List<ProductList>,
            onProduct: (ProductList) -> Unit,

){

    LazyColumn( contentPadding = PaddingValues(8.dp) )
    {

        items( productList ){ product->
            ProductListItem(
                image = product.image,
                title = product.title,
                price = product.price,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onProduct(product) }
            )

        }

    }
}




