package com.example.jetsubmission.Model

data class ProductList(
    val id: Int,
    val image: Int,
    val title: String,
    val price: String,
)