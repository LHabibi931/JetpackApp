package com.example.jetsubmission


import Product
import Profile
import androidx.compose.foundation.layout.padding
import androidx.compose.material.BottomNavigation
import androidx.compose.material.BottomNavigationItem
import androidx.compose.material.Text
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.jetsubmission.Model.ProductDataSource
import com.example.jetsubmission.Navigation.NavigationItem
import com.example.jetsubmission.Navigation.Screen
import com.example.jetsubmission.Screen.ProductDetail
import com.example.jetsubmission.Screen.ProductDetailViewModel
import com.example.jetsubmission.ui.theme.JetSubmissionTheme

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainApp(
    modifier: Modifier = Modifier,
    navController: NavHostController = rememberNavController()
){
    val productList = ProductDataSource.dummyProductList

    Scaffold( bottomBar = {BottomNav(navController)},
              modifier = Modifier) { innerPadding->
        NavHost(
            navController = navController,
            startDestination = Screen.Profile.route,
            modifier = Modifier.padding(innerPadding)
        ){

            composable(Screen.Profile.route){
                Profile()
            }

            composable(Screen.Product.route){
                val viewModel: ProductDetailViewModel = viewModel()

                Product(productList){  product->
                    viewModel.selectProduct(product)
                    navController.navigate( Screen.ProductDetail.createRoute(product.id) )

                }
            }


            composable(Screen.ProductDetail.route.replace("{productId}", "{productId}")){
                val productId = it.arguments?.getString("productId")?.toInt() ?: return@composable
                val product = productList.find { it.id == productId } ?: return@composable
                ProductDetail(product,
                              navigateBack = { navController.navigateUp()},)
            }

        }
    }

}


@Composable
private fun BottomNav( navController: NavHostController,
                       modifier: Modifier = Modifier

)
{
    BottomNavigation( modifier = Modifier,) {
        val navigationItems = listOf(
            NavigationItem(
                title = stringResource(R.string.items_title),
                icon = Icons.Default.Menu,
                screen = Screen.Product,
                contentDescription = "item_page"

            ),

            NavigationItem(
                title = stringResource(R.string.about_title),
                icon = Icons.Default.AccountCircle,
                screen = Screen.Profile,
                contentDescription = "about_page"
            ),
        )
        BottomNavigation {
            navigationItems.map { item->
                BottomNavigationItem(
                    icon = {
                        Icon(
                            imageVector = item.icon,
                            contentDescription = item.contentDescription,
                            tint = Color.White
                        )
                    },
                     label = { Text(item.title) },
                      selected = true,
                      onClick = {
                                navController.navigate(item.screen.route){
                                    popUpTo(navController.graph.findStartDestination().id){
                                        saveState = true
                                    }
                                    restoreState = true
                                    launchSingleTop = true
                                }
                      },

                )

            }

        }
    }

}


@Preview(showBackground = true)
@Composable
fun MainAppPreview(){
    JetSubmissionTheme {
        MainApp()
    }
}