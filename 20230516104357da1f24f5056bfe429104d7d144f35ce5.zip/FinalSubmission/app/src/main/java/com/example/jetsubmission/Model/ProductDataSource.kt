package com.example.jetsubmission.Model

import com.example.jetsubmission.R

object ProductDataSource {
    val dummyProductList = listOf(
        ProductList(1, R.drawable.zephyrus_g15, "Asus Zephyrus G15", "Rp. 25.0000.000"),
        ProductList(2, R.drawable.lenovo_legion, "Lenovo Legion 5", "Rp. 23.0000.000" ),
        ProductList(3, R.drawable.omen_15, "HP Omen 15", "Rp. 23.0000.000"),
        ProductList(4, R.drawable.asus_rog, "Asus ROG Strix G15", "Rp. 24.0000.000"),
        ProductList(5, R.drawable.lenovo_thinkpad, "Lenovo Thinkpad", "Rp. 4.600.000"),
        ProductList(6, R.drawable.zenbook_duo, "Asus Zenbook Duo", "Rp. 31.0000.000"),
        ProductList(7, R.drawable.razer_blade, "Razer Blade 15", "Rp. 37.0000.000"),
        ProductList(8, R.drawable.macbook_air, "Macbook Air M2", "Rp. 26.0000.000"),
        ProductList(9, R.drawable.acer_nitro, "Acer Nitro 5", "Rp. 20.0000.000"),
        ProductList(10, R.drawable.msi_gp66, "MSI GP66", "Rp. 23.0000.000"),

    )

    val dummyProductDesc = mapOf(
        //Zephyrus G15
        1 to ProductDesc("16 GB", "Ryzen 9 5900HS", "RTX 3060", "1.9 Kg", "15.6 Inch"),

        //Lenovo Legion
        2 to ProductDesc("16 GB", "Ryzen 7 5800H", "RTX 3060", "2.3 Kg", "15.6 Inch"),

        //Omen 15
        3 to ProductDesc("16 GB", "Intel Core i7-11750H", "RTX 3060", "2 Kg", "16.2 Inch"),

        //Asus ROG
        4 to ProductDesc("16 GB", "Intel Core i7-10750H", "RTX 3060", "2 Kg", "15.6 Inch"),

        //Lenovo Thinkpad
        5 to ProductDesc("16 GB", "Intel Core i7-1185G7", "Intel Iris Xe", "1.9 Kg", "15.6 Inch"),

        //Zenbook Duo
        6 to ProductDesc("24 GB", "Intel Core i9-119900H", "RTX 3070", "2.1 Kg", "15.6 Inch"),

        //Razer Balde 15
        7 to ProductDesc("32 GB", "Intel Core i9-119900H", "RTX 3070", "1.9 Kg", "15.6 Inch"),

        //Macbook Air
        8 to ProductDesc("16 GB", "M2 Chip", "Apple M2 GPU", "1.3 Kg", "13.5 Inch"),

        //Acer Nitro
        9 to ProductDesc("16 GB", "Ryzen 7 5800H", "RTX 3060", "2.1 Kg", "15.6 Inch"),

        //Msi GP66
        10 to ProductDesc("16 GB", "Intel Core i7-11750H", "RTX 3060", "2.1 Kg", "15.6 Inch"),
    )
}