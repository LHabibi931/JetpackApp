package com.example.jetsubmission.Screen

import android.annotation.SuppressLint
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.Icon
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.jetsubmission.Model.ProductDataSource
import com.example.jetsubmission.Model.ProductList
import com.example.jetsubmission.R

@SuppressLint("SuspiciousIndentation")
@Composable
fun ProductDetail(
    product: ProductList ,
    modifier: Modifier = Modifier,
    navigateBack: () -> Unit,
)
{
    val productDesc = ProductDataSource.dummyProductDesc[product.id]

       Column(
           Modifier
               .fillMaxWidth()
               .verticalScroll(rememberScrollState())
        ) {

            Box{
                Image(
                    painter = painterResource(product.image),
                    contentDescription = "",
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(350.dp),
                    contentScale = ContentScale.Crop
                )

                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Back",
                    modifier = Modifier
                        .padding(16.dp)
                        .clickable { navigateBack() }

                )

            }

            Spacer(modifier = Modifier.height(8.dp) )

            Text(
                text = product.title,
                style = MaterialTheme.typography.h4,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .padding(8.dp)

            )
           Text(
               text = "Harga : ${product.price}",
               style = MaterialTheme.typography.h5,
               modifier = Modifier
                   .padding(8.dp)
           )


            productDesc?.let { 
                
                Column( modifier = Modifier
                        .padding(8.dp)
                )
                {
                    Text(
                        text = stringResource(R.string.Spek),
                        style = MaterialTheme.typography.h5,
                        fontWeight = FontWeight.Bold
                    )
                    
                    Spacer(modifier = Modifier.height(8.dp) )
                    
                    Text(
                        text = "RAM: ${it.Ram}",
                        style = MaterialTheme.typography.body1,
                    )
                    Spacer(modifier = Modifier.height(8.dp) )
                    Text(
                        text = "Processor: ${it.Processor}",
                        style = MaterialTheme.typography.body1,
                    )
                    Spacer(modifier = Modifier.height(8.dp) )
                    Text(
                        text = "GPU: ${it.GraphicCard}",
                        style = MaterialTheme.typography.body1,
                    )
                    Spacer(modifier = Modifier.height(8.dp) )
                    Text(
                        text = "Berat: ${it.Berat}",
                        style = MaterialTheme.typography.body1
                    )
                    Spacer(modifier = Modifier.height(8.dp) )
                    Text(
                        text = "Ukuran Layar: ${it.UkuranLayar}",
                        style = MaterialTheme.typography.body1
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(16.dp) )

        }

    }


