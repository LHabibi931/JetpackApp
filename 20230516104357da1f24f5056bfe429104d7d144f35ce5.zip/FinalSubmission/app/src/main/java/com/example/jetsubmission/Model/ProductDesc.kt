package com.example.jetsubmission.Model

data class ProductDesc(
    val Ram: String,
    val Processor: String,
    val GraphicCard: String,
    val Berat: String,
    val UkuranLayar: String,
)
