@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.jetsubmission.Model

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.jetsubmission.R
import com.example.jetsubmission.ui.theme.JetSubmissionTheme

@Composable
fun ProductListItem(
    image: Int,
    title: String,
    price: String,
    modifier: Modifier = Modifier,
){
    Card(
        modifier = modifier
        .padding(8.dp)
        .fillMaxWidth(1f),
         shape = RoundedCornerShape(8.dp),
    ) {

        Row(modifier = Modifier) {

            Image(
                painter = painterResource(image),
                contentDescription = "",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(100.dp)

            )

            Column( modifier = Modifier ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(16.dp),
                )
                Text(
                    text = price,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(horizontal = 16.dp),
                )


            }


        }

    }

}



@Preview(showBackground = true)
@Composable
fun ProductListItemPreview(){
    JetSubmissionTheme {

    }
}