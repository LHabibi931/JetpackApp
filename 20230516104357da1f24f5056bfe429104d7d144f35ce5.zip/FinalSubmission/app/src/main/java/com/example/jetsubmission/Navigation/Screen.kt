package com.example.jetsubmission.Navigation

sealed class Screen(val route: String){
    object Product : Screen("product")
    object Profile : Screen("profile")
    object ProductDetail: Screen("product/{productId}"){
        fun createRoute(productId: Int) = "product/$productId"
    }
}
